<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:62:"E:\www\homefit\public/../application/admin\view\pro\index.html";i:1593254787;}*/ ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>后台管理系统</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="/static/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="/static/assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="/static/assets/css/index.css" rel="stylesheet" />
    <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div id="wrapper">
    <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a  class="navbar-brand" href="<?php echo url('admin/index/index'); ?>">
                产品管理系统
            </a>
        </div>

        <div class="notifications-wrapper">
            <ul class="nav">
                <!-- <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa"></i> Admin <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-sign-out"></i> Logout</a>
                        </li>
                    </ul>
                </li> -->
            </ul>
        </div>
    </nav>

    <!-- /. NAV TOP  -->
    <nav  class="navbar-default navbar-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav" id="main-menu">
                <li>
                    <a class="active-menu"  href="<?php echo url('admin/pro/index'); ?>"><i class="fa fa-dashboard "></i>产品管理</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- /. SIDEBAR MENU (navbar-side) -->
    <div id="page-wrapper" class="page-wrapper-cls">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-head-line">产品管理</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <a href="<?php echo url('admin/index/index'); ?>"><input type="submit" class="btn btn-danger btn-link-1" value="新增"></a>
                    <a href=""><input type="submit" class="btn btn-danger btn-link-1 delAll" value="删除"></a>
                    <!--    Striped Rows Table  -->
                    <div class="panel panel-default">

                        <div class="panel-heading">
                            产品管理--列表
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                        <th><input type="checkbox" class="chooseAll" id="chooseAll" ></th>
                                        <th>名称</th>
                                        <th>价格</th>
                                        <th>产品图</th>
                                        <th>hover图</th>
                                        <th>操作</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php if(is_array($proList) || $proList instanceof \think\Collection || $proList instanceof \think\Paginator): $i = 0; $__LIST__ = $proList;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$pro): $mod = ($i % 2 );++$i;?>
                                    <tr>
                                        <td><input type="checkbox" class="chooseOne" id="chooseOne" value="<?php echo $pro['id']; ?>"></td>
                                        <td><?php echo $pro['pro_name']; ?></td>
                                        <td><?php echo $pro['pro_price']; ?></td>
                                        <td><?php echo $pro['pic']; ?></td>
                                        <td><?php echo $pro['pic_hover']; ?></td>
                                        <td><a href="#" class="btn btn-danger btn-xs">编辑</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; endif; else: echo "$empty" ;endif; ?>
                                    </tbody>
                                </table>

                            </div>

                        </div>
                    </div>
                    <!--  End  Striped Rows Table  -->
                    <?php echo $pages; ?>
                </div>
            </div>
        </div>

    </div>
    <footer >

    </footer>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="/static/assets/js/jquery-1.11.1.min.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="/static/assets/bootstrap/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="/static/assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="/static/assets/js/custom.js"></script>
    <script>

        $("#chooseAll").click(function () {
            $(".chooseOne").prop("checked",$(this).prop("checked"));

        });
    </script>
    <script>
        $(".delAll").click(function () {
            if(($(".chooseOne:checked").length) < 1){
                alert("请选择一个");
                return false;
            }
            let idStr = "";
            $(".chooseOne:checked").each(function () {
                idStr += $(this).val()+",";
            });
            alert(idStr);
            $.post("<?php echo url('admin/pro/delete'); ?>",{"idStr":idStr},function (result) {
                location.href = "<?php echo url('admin/pro/index'); ?>"
            },"json");
        })
    </script>
</body>
</html>
