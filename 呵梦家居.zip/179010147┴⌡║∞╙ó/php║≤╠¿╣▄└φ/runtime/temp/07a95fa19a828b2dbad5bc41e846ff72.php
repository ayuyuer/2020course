<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:63:"E:\www\homefit\public/../application/admin\view\shop\index.html";i:1593254067;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>官方商城</title>
    <link rel="stylesheet" href="/static/css/public.css">
    <link rel="stylesheet" href="/static/css/animate.css">
    <link rel="stylesheet" href="/static/css/index.css">

</head>
<body>
<!--logo-->
<header>
    <img src="/static/images/logo.png">
    <div class="head_right">
        <ul >
            <li><a href=""><img src="/static/images/购物车.png"></a><a href="">购物车</a></li>
            <li><a href="login.html"><img src="/static/images/登录.png"></a><a href="login.html">登录</a></li>
        </ul>

    </div>
    <!---->
    <div class="search">
        <input type="text" placeholder="搜一搜">
        <button></button>
    </div>
    <div class="clears"></div>
</header>
<!--logo end-->


<div>
    <!--导航-->
    <nav>
        <ul class="nav">
            <li class="on"><a href="index.html">首页</a></li>
            <li><a href="">品牌动态</a></li>
            <li><a href="">我家show</a>
                <ul class="subNav">
                    <li><a href="">田园风</a></li>
                    <li><a href="">美式风</a></li>
                    <li><a href="">中式风</a></li>
                    <li><a href="">欧式风</a></li>
                    <li><a href="">个性混搭</a></li>
                </ul>
            </li>
            <li><a href="">官方商城</a>
                <ul class="subNav">
                    <li><a href="">家具区</a></li>
                    <li><a href="">服饰区</a></li>
                    <li><a href="">装饰区</a></li>
                    <li><a href="">餐具区</a></li>
                    <li><a href="">家纺区</a></li>
                </ul>
            </li>
            <li><a href="">好物推荐</a>
                <ul class="subNav">
                    <li><a href="">达人推荐</a></li>
                    <li><a href="">火热趋势</a></li>
                </ul></li>
            <li><a href="">设计投稿</a></li>
            <li><a href="">联系我们</a></li>

        </ul>
        <div class="clears"></div>
    </nav>
    <!--导航 end-->

    <!--内容-->
    <div class="shop">
        <div class="shopNav">
            <img src="/static/images/装饰区.png.">
            <ul>
                <li><a href="">花/花瓶</a></li>
                <li><a href="">灯饰</a></li>
                <li><a href="">座钟</a></li>
                <li><a href="">书桌摆件</a></li>
                <li><a href="">蜡烛/烛台</a></li>
                <li><a href="">收纳容器</a></li>
                <li><a href="">卫浴香薰</a></li>
            </ul>
        </div>
        <div class="clears"></div>

        <div class="shopShow">
            <ul>
                <li>
                    <a href="intro.html">
                        <div class="imgBox">
                            <img  class="imgFirst" src="/static/images/zsimg1.png">
                            <img  class="imgChange" src="/static/images/zsimg01.jpg">
                        </div>
                        <p>Snape 玻璃花瓶</p>
                        <p >￥680</p>
                    </a>

                </li>
                <li>
                    <a href="">
                        <div class="imgBox">
                            <img  class="imgFirst" src="/static/images/zs_img2.png">
                            <img  class="imgChange" src="/static/images/zsimg02.jpg">
                        </div>

                        <p>Hermione 玻璃花瓶</p>
                        <p >￥680</p>
                    </a>

                </li>
                <li>
                    <a href="">
                        <div class="imgBox">
                            <img  class="imgFirst" src="/static/images/zs_img3.png">
                            <img  class="imgChange" src="/static/images/zsimg03.jpg">
                        </div>
                        <p>Sylvia 挂耳陶瓷花瓶</p>
                        <p >￥680</p>
                    </a>

                </li>
                <li>
                    <a href="">
                        <div class="imgBox">
                            <img  class="imgFirst" src="/static/images/zs_img4.png">
                            <img  class="imgChange" src="/static/images/zsimg04.jpg">
                        </div>
                        <p>Lorry 直筒玻璃花瓶</p>
                        <p >￥680</p>
                    </a>

                </li>
            </ul>
            <ul>
                <?php if(is_array($proList) || $proList instanceof \think\Collection || $proList instanceof \think\Paginator): $i = 0; $__LIST__ = $proList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$pro): $mod = ($i % 2 );++$i;?>
                <li>
                    <a href="intro.html">
                        <div class="imgBox">
                            <img  class="imgFirst" src="/static/images/<?php echo $pro['pic']; ?>">
                            <img  class="imgChange" src="/static/images/<?php echo $pro['pic_hover']; ?>">
                        </div>
                        <p><?php echo $pro['pro_name']; ?></p>
                        <p ><?php echo $pro['pro_price']; ?></p>
                    </a>
                </li>
                <?php endforeach; endif; else: echo "" ;endif; ?>
               <!-- <li>
                    <a href="">
                        <div class="imgBox">
                            <img  class="imgFirst" src="/static/images/zs_img6.png">
                            <img  class="imgChange" src="/static/images/zsimg06.jpg">
                        </div>
                        <p>Wink 皇冠金属摆件</p>
                        <p >￥680</p>
                    </a>

                </li>
                <li>
                    <a href="">
                        <div class="imgBox">
                            <img  class="imgFirst" src="/static/images/zs_img7.png">
                            <img  class="imgChange" src="/static/images/zsimg07.jpg">
                        </div>
                        <p>Anaheim 海星玻璃摆件</p>
                        <p >￥680</p>
                    </a>

                </li>
                <li>
                    <a href="">
                        <div class="imgBox">
                            <img  class="imgFirst" src="/static/images/zs_img8.png">
                            <img  class="imgChange" src="/static/images/zsimg08.jpg">
                        </div>
                        <p>Pan 对装木制雕花摆件</p>
                        <p >￥680</p>
                    </a>

                </li>-->
            </ul>

            <!--<ul>-->
                <!--<li>-->
                    <!--<a href="">-->
                        <!--<div class="imgBox">-->
                            <!--<img  class="imgFirst" src="/static/images/zs_img9.png">-->
                            <!--<img  class="imgChange" src="/static/images/zsimg09.jpg">-->
                        <!--</div>-->
                        <!--<p>穹顶铜质座钟</p>-->
                        <!--<p >￥680</p>-->
                    <!--</a>-->

                <!--</li>-->
                <!--<li>-->
                    <!--<a href="">-->
                        <!--<div class="imgBox">-->
                            <!--<img  class="imgFirst" src="/static/images/zs_img10.png">-->
                            <!--<img  class="imgChange" src="/static/images/zsimg10.jpg">-->
                        <!--</div>-->
                        <!--<p>方形贝母座钟</p>-->
                        <!--<p >￥680</p>-->
                    <!--</a>-->

                <!--</li>-->
                <!--<li>-->
                    <!--<a href="">-->
                        <!--<div class="imgBox">-->
                            <!--<img  class="imgFirst" src="/static/images/zs_img11.png">-->
                            <!--<img  class="imgChange" src="/static/images/zsimg11.jpg">-->
                        <!--</div>-->
                        <!--<p>圆形铜质座钟</p>-->
                        <!--<p >￥680</p>-->
                    <!--</a>-->

                <!--</li>-->
                <!--<li>-->
                    <!--<a href="">-->
                        <!--<div class="imgBox">-->
                            <!--<img  class="imgFirst" src="/static/images/zs_img12.png">-->
                            <!--<img  class="imgChange" src="/static/images/zsimg12.jpg">-->
                        <!--</div>-->
                        <!--<p>穹顶贝母座钟</p>-->
                        <!--<p >￥680</p>-->
                    <!--</a>-->
                <!--</li>-->
            <!--</ul>-->
        </div>
        <div class="clears"></div>
        <div class="page">
            <?php echo $pages; ?>
        </div>
    </div>
    <!--内容end-->
    <!--页尾-->
    <div class="footer">
        <div class="content_3">
            <div class="fLeft">
                <img src="/static/images/联系.png">
            </div>
            <div class="fMiddle">
                <ul >
                    <li><a href="">天猫旗舰店 </a></li>
                    <li><a href="">售后服务 </a></li>
                    <li><a href="">配送服务 </a></li>



                </ul>
                <ul>
                    <li><a href="">法律声明 </a></li>
                    <li><a href="">服务条款 </a></li>
                    <li><a href="">版权声明 </a></li>

                </ul>

                <ul>
                    <li><a href="">联系我们 </a></li>
                    <li><a href="">常见问题 </a></li>
                    <li><a href="">我要投稿 </a></li>
                </ul>

            </div>
            <div class="fRight">
                <ul>
                    <li><a href=""><img src="/static/images/微博.png"></a></li>
                    <li><a href=""><img src="/static/images/微信.png"></a></li>
                    <li><a href=""><img src="/static/images/邮件.png"></a></li>
                </ul>
            </div>
            <div class="clears"></div>
            <div class="fBottom">
                <ul>
                    <li><a>版权所有：深圳市呵梦家居有限公司</a> <a>全国统一热线：400-161-1808 </a><a>电话：0755-61881808</a> <a>传真：0755-61881868</a> 公司地址：深圳市福田区福田保税区绒花路138号（城市3米6公寓）4楼</li>
                    <li class="center"><img src="/static/images/beian.png">备案：粤备ICP14011927号-3</li>
                </ul>

            </div>
        </div>


    </div>
    <!---->

</div>





</body>
</html>