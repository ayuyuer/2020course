<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:63:"E:\www\homefit\public/../application/admin\view\index\menu.html";i:1593196621;}*/ ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>后台管理系统</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="/static/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <!-- FONTAWESOME ICONS STYLES-->
    <link href="/static/assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <!--CUSTOM STYLES-->
    <link href="/static/assets/css/index.css" rel="stylesheet" />
    <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div id="wrapper">
    <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a  class="navbar-brand" href="index.html">
                XXXX后台管理系统
            </a>
        </div>

        <div class="notifications-wrapper">
            <ul class="nav">
                <!-- <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa"></i> Admin <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-sign-out"></i> Logout</a>
                        </li>
                    </ul>
                </li> -->
            </ul>
        </div>
    </nav>

    <!-- /. NAV TOP  -->
    <nav  class="navbar-default navbar-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav" id="main-menu">
                <li>
                    <a class="active-menu"  href="productList-选做.html"><i class="fa fa-dashboard "></i>产品管理</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- /. SIDEBAR MENU (navbar-side) -->
    <div id="page-wrapper" class="page-wrapper-cls">
        <div id="page-inner">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-head-line">产品管理</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            产品管理--新增
                        </div>
                        <div class="panel-body">
                            <form action="productList-选做.html">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">产品名</label>
                                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="请输入产品名" />
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">简介</label>
                                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="请输入简介，不超过12个字" />
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputFile">产品缩略图</label>
                                    <input type="file" id="exampleInputFile" />
                                    <p class="help-block">请输入图片格式jpg,jpge,png,gif。建议尺寸184 X 234</p>
                                </div>
                                <hr />
                                <textarea class="form-control" rows="3" placeholder="请用KindEditor富文本编辑器插件"></textarea>
                                <hr />
                                <button type="submit" class="btn btn-primary">Submit</button>
                                <hr />
                                <div class="alert alert-danger">
                                    这里是错误信息提示示例.
                                </div>
                                <div class="form-group has-success">
                                    <label class="control-label" for="success">如果用到JS或JQuery提示，正确的输入框</label>
                                    <input class="form-control" id="success" type="text">
                                </div>
                                <div class="form-group has-warning">
                                    <label class="control-label" for="warning">如果用到JS或JQuery提示，警告的输入框</label>
                                    <input class="form-control" id="warning" type="text">
                                </div>
                                <div class="form-group has-error">
                                    <label class="control-label" for="error">
                                        如果用到JS或JQuery提示，错误的输入框
                                    </label>
                                    <input class="form-control" id="error" type="text">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<footer >

</footer>
<!-- /. FOOTER  -->
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->
<script src="/static/assets/js/jquery-1.11.1.min.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="/static/assets/bootstrap/js/bootstrap.min.js"></script>
<!-- METISMENU SCRIPTS -->
<script src="/static/assets/js/jquery.metisMenu.js"></script>
<!-- CUSTOM SCRIPTS -->
<script src="/static/assets/js/custom.js"></script>
</body>
</html>
