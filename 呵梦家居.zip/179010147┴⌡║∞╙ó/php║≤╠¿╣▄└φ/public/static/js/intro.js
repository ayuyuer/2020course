{
    let imgShow = document.getElementById("imgShow");
    let imgSelect = document.querySelector("#imgSelect");
    let imgBtn = imgSelect .children;

    let proImgs = [{
        img:"images/zsimg01.jpg"
    },{
        img:"images/zs_img1.png"
    },{
        img:"images/zsimg0102.jpg"
    }];
    index = 0;
    //  显示图片

     for(let i = 0; i<imgBtn.length;i++) {
         imgBtn[i].index = i;
         imgBtn[i].onmouseenter = function () {
             for (let m = 0; m < proImgs.length; m++) {
                 imgBtn[m].className = "";
             }
             this.className = "btnShow";
             imgShow.src = proImgs[i].img;

         }
     }

}
