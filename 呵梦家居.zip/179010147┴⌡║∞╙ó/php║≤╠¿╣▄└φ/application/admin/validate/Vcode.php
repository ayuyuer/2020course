<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2020/6/23
 * Time: 13:43
 */

namespace app\admin\validate;


use think\Validate;

class vcode extends Validate
{
    protected $rule = [

        'uname' => 'require|alphaDash|length:5,20',
        'upwd' => 'require|alphaNum',
//        'reupwd'=>'require|confirm:upwd',
//        'vcode'=>'require|captcha'
    ];

    protected $message = [
//        'uname.unique' => '欢迎登录!',

        'uname.require' => '请填写用户名!',
        'uname.alphaDash' => '用户名只能由字母数字-_组成！',
        'uname.length' => '用户名5-20位！',
        'upwd.require' => '请填写密码!',
        'upwd.alphaNum' => '密码只能字母数字组成',
//        'vcode.captach'=>'验证码错误！',
    ];
}