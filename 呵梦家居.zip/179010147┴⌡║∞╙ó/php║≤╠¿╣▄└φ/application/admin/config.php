<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2020/6/18
 * Time: 23:35
 */
return[
    "admin_page_count"=>8,

];