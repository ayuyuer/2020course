<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2020/6/27
 * Time: 18:03
 */

namespace app\admin\controller;


use think\Controller;

class Shop extends Controller
{
    public function index(){
        $proModel = new \app\admin\model\pro();
        $proList = $proModel->getList();
        $pages = $proList->render();
        $empty = '<td align="center" colspan="5">暂无任何数据</td>';
        $this->assign("proList", $proList);
        $this->assign("pages", $pages);
        $this->assign("empty", $empty);
        return $this->fetch();
    }

}