<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/4/8
 * Time: 14:12
 */

namespace app\admin\controller;


use think\captcha\Captcha;
use think\Controller;
use think\Loader;
use think\Request;
use think\Session;

class Login extends Controller
{
    /**
     * 显示登录页面
     */
    public function index()
    {
//        $this->view->engine->layout(false);
        return $this->fetch();
    }
    /**
     * 处理登录提交的数据
     */
    public function doLogin()
    {
        $request = Request::instance();
        if ($request->isPost()) {
            //获取表单提交数据
            $postData = $request->post();
//            //验证表单提交数据是否合法
//            $userVal = Loader::validate("Vcode");
//            if (!$userVal->check($postData)) {
//                $this->error($userVal->getError());
//            }
            //数据库里验证用户名密码是否存在
            $userName = $postData['uname'];
            $userPwd = $postData['upwd'];
            $userModel = new \app\admin\model\Users();
            $userData = $userModel->checkUser($userName, $userPwd);
            dump($userData->toArray());
            if (empty($userData)) {
                $this->error("用户名或密码错误！");
            } else if ($userData->uname != $postData['uname']) {
                $this->error("登录失败！");
            } else {
                if($userData){
                    Session::set("uid",$userData->id);
                    Session::set("uname",$userData->uname);
                    $this->success("登录成功", "admin/index/index");
                }
                //跳转页面

            }


////            dump($postData);
//            if ($request->has("uname")){
//                $userName = $request->post("uname");
//                $userPwd = $request->post("upwd");
////                $userName = input("post.uname");
//                dump($userName);
//                dump($userPwd);
//            }else{
//                $this->error("非法操作2");
//            }
        } else {
            $this->error("非法操作");
        }
    }


    /**
     * @return mixed
     */
  /*  public function getVcode()
    {
        $config = [
            "codeSet"=>"123456789",
            "length"=>4,
            "useNoise"=>false,

        ];*/

        /** @var TYPE_NAME $captcha */
        /*$captcha = new Captcha( $config);
        return $captcha->entry();
    }*/

}