<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/6/14
 * Time: 23:03
 */

namespace app\admin\controller;


use think\Controller;

class Index extends Controller
{
    public function index(){
        return $this->fetch();
    }

    public function header(){
        return $this->fetch();
    }

    public function menu(){
        return $this->fetch();
    }

    public function system(){
        return $this->fetch();
    }
}