<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2020/6/27
 * Time: 2:44
 */

namespace app\admin\controller;


use think\Controller;
use think\Request;

class Pro extends Controller
{
    public function index(){
        $proModel = new \app\admin\model\pro();
        $proList = $proModel->getList();
        $pages = $proList->render();
        $empty = '<td align="center" colspan="5">暂无任何数据</td>';
        $this->assign("proList", $proList);
        $this->assign("pages", $pages);
        $this->assign("empty", $empty);
        return $this->fetch();
    }
    public function add(){
//        $roleModel = new Role();
//        $roleData = $roleModel->getRole();
////        dump($roleData);
//        $this->assign("roleList", $roleData);
        return $this->fetch();
    }

    /**
     * 处理新增
     */
    public function doAdd(){
        $postData = Request::instance()->param();
        dump($postData);
        $proData = [
            'pro_name' => $postData['name'],
            'pro_price' => $postData['price'],
            'pic' => $postData['pic1'],
            'pic_hover' => $postData['pic2'],
        ];
        dump($proData);
        $proModel = new \app\admin\model\pro();
        $addResult = $proModel->addPro($proData);
        if ($addResult === false){
            $this->error("添加失败");
        }else {
            $this->success("添加成功","admin/pro/index");
        }

    }
    public function delete(){
        if (Request::instance()->isAjax()){
            $proModel = new \app\admin\model\pro();
            $data = $proModel->delete();
            if ($data != false){
                echo json_encode(array("flag"=>1,"msg"=>"成功"));
            }else {
                echo json_encode(array("flag"=>0,"msg"=>"失败"));
            }
        }else {
            echo json_encode(array("flag"=>0,"msg"=>"失败"));
        }
    }
}