<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2020/6/27
 * Time: 18:03
 */

namespace app\admin\model;


use think\Config;
use think\Model;
use think\Request;

class shop extends  Model
{

    /**
     * @return \think\Paginator
     * @throws \think\exception\DbException
     */
    public function getList()
    {
        $searchForm = Request::instance()->get();
        $map = array();

        $pageCount = Config::get("admin_page_count");
        return $this->where($map)->paginate($pageCount, false, [
            "query" => Request::instance()->get()
        ]);
    }

    public function getProById($id){
        return $this->where(["id"=>$id])->find();
    }
}