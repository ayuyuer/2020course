<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2020/6/27
 * Time: 2:45
 */

namespace app\admin\model;


use think\Config;
use think\Model;
use think\Request;

class pro extends Model
{
    public function getList()
    {
        $searchForm = Request::instance()->get();
        $map = array();

        $pageCount = Config::get("admin_page_count");
        return $this->where($map)->paginate($pageCount, false, [
            "query" => Request::instance()->get()
        ]);
    }

        public function getProById($id){
        return $this->where(["id"=>$id])->find();
    }

    public function delete(){
        $postData = Request::instance()->post();
        $idStr = $postData["idStr"];
//        $status = $postData["status"];
        $map["id"] = ["IN", trim($idStr,",")];
        return $this->where($map)->delete();
    }
    public function getUser(){
        echo $this->name;
    }

    public function addPro($proData){
        $affectRows = $this->insert($proData);
        if ($affectRows > 0){
            return $this->getLastInsID();
        }else {
            return false;
        }
    }

    public function addProList(){
        //数据库insert或者insertAll添加
//        $usersData = [
//            ['user_name'=>'uname1',
//            'user_pwd' => md5('123456789')],
//            ['user_name'=>'uname2',
//                'user_pwd' => md5('123456789')],
//            ['user_name'=>'uname3',
//                'user_pwd' => md5('123456789')],
//        ];
//        $affectRows = $this->insertAll($usersData);
        //模型的添加save
        $this->data(
            ['roleName'=>'model1',
                'user_pwd' => md5('123456789')]
        );
        $affectRows = $this->save();
        if ($affectRows > 0){
            return $this->id;
//            return $this->insertGetId($usersData);
        }else {
            return false;
        }
    }
}