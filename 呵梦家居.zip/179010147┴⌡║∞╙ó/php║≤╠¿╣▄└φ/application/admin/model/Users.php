<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2020/6/27
 * Time: 15:31
 */

namespace app\admin\model;


use think\Model;

class Users extends Model
{
    public function checkUser($uname, $upwd){
        $map['uname'] = $uname;
        $map['upwd'] = $upwd;
        $data = $this->where($map)->find();
//        $where['id'] = 2;
//        //SELECT user_name,user_pwd FROM `cms_users` WHERE id = 2;
//        $this->find();//SELECT * FROM `cms_users` LIMIT 1
//        $this->select();//SELECT * FROM `cms_users`
//        $this->where($where)->find();//SELECT * FROM `cms_users` WHERE `id` = 2 LIMIT 1
//        //SELECT user_name,user_pwd FROM `cms_users` WHERE user_name LIKE '%t%' and id=3
//        $map['user_name'] = ['LIKE','%t%'];
//        $map['id'] = 3;
//        $data = $this->field('user_name,user_pwd')->where($map)->find();
//        echo $this->getLastSql();
//        dump($data->toArray());
        return $data;
    }
}