{
    let picUl = document.getElementById("picUl");
    let jianBtn = document.getElementById("jian");
    let numShow = document.getElementById("numShow");
    let jiaBtn = document.getElementById("jia");

    //banner切换
    let imgs = [{
        img: "images/banner01.png"
    }, {
        img: "images/banner02.png"
    }, {
        img: "images/banner03.png"
    }];


    //默认图
    let  index = 0;
    //banner
    let showPic = function (index) {
        picUl.style.background = `url("${ imgs[index].img }") top center no-repeat`;
    };

    //banner轮播
    function lunbo(event) {
        index++;
        if (index > imgs.length - 1) {
            index = 0;
        }
        showPic(index);
    }
    //轮播时间
    setInterval("lunbo()",2000);
    console.info(imgs);

    //加法
    let jiaFun = function(event){
        // 取出当前的 值
        let v =numShow.value ;   // 获取当前值，字符串
        let res = Number(v) + 1;
        numShow.value = res ;

    };
    //减法
    //  添加事件监听
    jiaBtn.addEventListener("click", jiaFun );
    let jianFun = function(event){
        // 取出当前的 值
        let v = numShow.value ;   // 获取当前值，字符串
        let res = Number(v) - 1;
        if(res>=1)
        {
            numShow.value = res ;
        }
       else {
            return false;
        }

    };
    //  添加事件监听
    jianBtn.addEventListener("click", jianFun );
}