// JavaScript Document


var k =0;

$(document).ready(function(){
		rr()
		 });
				 
function rr(){
	$("#an>li").hover(
	function(){
		k=$(this).attr("value");
		$("#xx>div").hide();
		$("#an>li").css("background","#fff");
		
		$("#an"+k).css("background","#f7f7f7");
		
		$("#x"+k).show();
		$("#next_b").css("top","200px");
		event.preventDefault();	
       },
      function(){}
	   )
	   
	   
	   $("#xx>div").hover(
	  function(){},
      function(){
		  $("#xx>div").hide();
		  $("#an>li").css("background","#fff");
		  $("#next_b").css("top","0px");
		  event.preventDefault();	
		  }
		  )
}