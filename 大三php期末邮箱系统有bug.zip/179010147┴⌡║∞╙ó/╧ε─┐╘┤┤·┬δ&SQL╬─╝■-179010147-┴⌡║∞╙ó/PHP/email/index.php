<meta charset="utf-8">
<?php include_once ("head.php")?>
<?php include_once ("sidebar.php")?>
    <!--content开始-->
    <div class="content">

    </div>
    <!--content结束-->
<?php include_once ("footer.php")?>