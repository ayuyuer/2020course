<meta charset="utf-8">
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>已发送</title><link rel="stylesheet" type="text/css" href="css/public.css"><link rel="stylesheet" type="text/css" href="css/receive.css">
</head>

    <?php include_once ("underhead.php")?>
    <?php include_once ("sidebar.php")?>
    <!--content开始-->
    <div class="content">

        <form class="form ">
            <table class="table" cellpadding="0" cellspacing="0">
                <thead>
                <tr>
                    <th><input type="checkbox"></th><th >序号</th><th>主题</th><th>收件人</th><th>发件日期</th><th>操作</th>
                </tr>
                </thead>
                <tbody>
                <?php


                $username=$_SESSION['username'];
                include_once ("./conn/conn.php");   //引入数据库连接文件

                //分页参数：页码$page,每页条数$pagesize,记录条数$rownum,总页数$pagecount
                $page=isset($_GET['page'])?$_GET['page']:1; //获取地址栏的page参数，如果没有就赋初值为1
                $pagesize=4;    //每一页显示的数据条数
                //获取当前数据表的记录条数

                $sql="select * from email where sname='$username'and status=0";  //定义待执行的sql语句
                $result=mysqli_query($link,$sql);   //3 执行sql语句
                if(!$result)    //如果sql执行不成功
                {
                    echo "sql执行不成功，错误是：".mysqli_error($link)."你用的sql语句是".$sql;  //打印错误，打印sql语句
                    exit;
                }
                $rownum=mysqli_num_rows($result);    //读取结果集中记录的条数
                $pagecount=ceil($rownum/$pagesize); //算出总的页数


                //分页显示查询
                $sql="select * from email where sname='$username' and status=0 limit ".($page-1)*$pagesize.",$pagesize";  //定义待执行的sql语句
                $result=mysqli_query($link,$sql);   //3 执行sql语句
                if(!$result)    //如果sql执行不成功
                {
                    echo "sql执行不成功，错误是：".mysqli_error($link)."你用的sql语句是".$sql;  //打印错误，打印sql语句
                    exit;
                }
                while($row=mysqli_fetch_array($result))     //4 循环读取结果集
                {
                    ?>
                    <tr>
                        <td><input type="checkbox"></td>
                        <td><?php echo $row['id'];?></td>
                        <td><?php echo $row['title'];?></td>
                        <td><?php echo $row['rname'];?></td>
                        <td><?php echo $row['date'];?></td>
                        <td>
                            <div class="but">
                                <button><a href="s-vmore.php?id=<?php echo $row['id'];?>">查看</a></button>

                            </div>
                        </td>
                    </tr>
                    <?php
                }
                mysqli_free_result($result);    //6 释放结果集
                mysqli_close($link);    //7 释放连接
                ?>
                </tbody>


                <div class="rec right">
                    共<?php echo $rownum;?>封邮件  <div class="date">
                        <ul>
                            <li <?php echo ($page<=1?:"");?>><a href="?page=<?php echo ($page<=1)?1:$page-1;?>">上一页</a></li>
                            <?php
                            for($i=1;$i<=$pagecount;$i++)
                            {
                                ?>
                                <li <?php echo ($page==$i?:"");?>><a href="?page=<?php echo $i;?>"><?php echo $i;?></a></li>
                                <?php
                            }
                            ?>
                            <li  <?php echo ($page>=$pagecount?:"");?>><a href="?page=<?php echo ($page>=$pagecount)?$pagecount:$page+1;?>">下一页</a></li>
                        </ul>
                    </div>
                </div>
        </form>
        <div class="clears"></div>
    </div>

    <!--content结束-->

    <div class="clears"></div>
    <!--footer开始-->
    <div class="footer">
        <p align="center"> 2019 fish Inc. All Rights Reserved.</p>
    </div>
    <!--footer结束-->
</div>

</body>
</html>
