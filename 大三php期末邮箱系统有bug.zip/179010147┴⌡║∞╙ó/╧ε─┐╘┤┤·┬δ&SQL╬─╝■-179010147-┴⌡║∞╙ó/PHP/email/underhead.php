<body>
<body style="background-image:url(images/in-bg.png); background-size:cover; background-repeat:no-repeat;">
<div>

    <!--nav开始-->
    <div class="nav">
        <div class="logo left">
            <img src="images/logo.png">
        </div>
        <?php
        session_start();
        $username=$_SESSION['username'];

        ?>
        <div class="user"><span style="position absolute;right: 20%;color: #03a3fc; font-size: 18px;"><?php echo $username;?></span></div>
        <div class="logout"><span class="right"><a href=" logout.php">退出</a></span></div>
    </div>
    <!--nav结束-->