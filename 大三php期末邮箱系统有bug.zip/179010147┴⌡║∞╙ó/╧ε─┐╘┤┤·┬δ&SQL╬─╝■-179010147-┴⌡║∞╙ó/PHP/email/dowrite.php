<meta charset="utf-8">
<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2019/12/30
 * Time: 21:01
 * 执行添加，成功后跳转到主页
 */
session_start();
$username=$_SESSION['username'];

$rname=isset($_POST['rname'])?$_POST['rname']:"";  //获取发件人数据，没有就赋初值空串
$title=isset($_POST['title'])?$_POST['title']:"";  //获取title数据，没有就赋初值空串
$text=isset($_POST['text'])?($_POST['text']):"";  //获取text数据，没有就赋初值空串
date_default_timezone_set("PRC");
$date=date('Y-m-d H:i:s');
include_once ("./conn/conn.php");   //引入数据库连接文件
$sql="insert into email(rname,title,text,sname,date) values ('$rname','$title','$text','$username','$date')";  //定义待执行的sql语句
$result=mysqli_query($link,$sql);   //3 执行sql语句
if(!$result)    //如果sql执行不成功
{
    echo "sql执行不成功，错误是：".mysqli_error($link)."你用的sql语句是".$sql;  //打印错误，打印sql语句
    exit;
}
else{
    echo "<script>alert('发送成功！');location.href='index.php';</script>";  //跳转到index
}
?>
