
<div class="clears"></div>
<!--footer开始-->
<div class="footer">
    <p align="center"> 2019 fish Inc. All Rights Reserved.</p>
</div>
<!--footer结束-->
</div>

</body>
</html>