<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2019/12/26
 * Time: 19:08
 */
$link=mysqli_connect("localhost","root","root","email");   //1 2 连接mysql,选择数据库email
mysqli_query($link,"set names utf8");   //设置数据库的编码类型为utf8