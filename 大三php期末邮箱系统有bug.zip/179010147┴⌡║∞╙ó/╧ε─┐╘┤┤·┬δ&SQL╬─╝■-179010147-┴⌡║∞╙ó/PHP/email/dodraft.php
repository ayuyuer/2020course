<meta charset="utf-8">
<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2019/12/31
 * Time: 9:25
 */

session_start();
$username=$_SESSION['username'];

date_default_timezone_set("PRC");
$date=date('Y-m-d H:i:s');
$rname=isset($_POST['rname'])?$_POST['rname']:"";  //获取发件人数据，没有就赋初值空串
$title=isset($_POST['title'])?$_POST['title']:"";  //获取title数据，没有就赋初值空串
$text=isset($_POST['text'])?($_POST['text']):"";  //获取text数据，没有就赋初值空串
$status=1;
include_once ("./conn/conn.php");   //引入数据库连接文件
$sql="insert into email(rname,title,text,sname,date,status) values ('$rname','$title','$text','$username','$date','$status')";  //定义待执行的sql语句
$result=mysqli_query($link,$sql);   //3 执行sql语句
if(!$result)    //如果sql执行不成功
{
    echo "sql执行不成功，错误是：".mysqli_error($link)."你用的sql语句是".$sql;  //打印错误，打印sql语句
    exit;
}
else{
    echo "<script>alert('已存入草稿！');location.href='draft.php';</script>";  //跳转到index
}
?>
