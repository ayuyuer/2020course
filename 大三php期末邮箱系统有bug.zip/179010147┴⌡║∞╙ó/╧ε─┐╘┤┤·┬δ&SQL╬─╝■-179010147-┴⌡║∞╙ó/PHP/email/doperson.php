<meta charset="utf-8">
<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2019/12/27
 * Time: 9:23
 */
if(!isset($_POST['submit'])) //用户直接访问本页
{
    echo "<script>alert('请选择个人资料进行修改！');location.href='person.php';</script>";  //跳转到person
    exit;
}
$name=isset($_POST['name'])?$_POST['name']:"";//获取表单的name,没有初值设置空串
$gender=isset($_POST['gender'])?$_POST['gender']:"";//获取表单的gender,没有初值设置空串
$uid=isset($_POST['uid'])?$_POST['uid']:"";//获取表单的uid,没有初值设置空串
include_once ("./conn/conn.php");   //引入数据库连接文件
$sql="update user set name='$name',gender='$gender' where uid='$uid'";//设置msql查询语句
$result=mysqli_query($link,$sql);//执行msql查询语句
if(!$result)    //如果sql执行不成功
{
    echo "sql执行不成功，错误是：".mysqli_error($link)."你用的sql语句是".$sql;  //打印错误，打印sql语句
    exit;
}
else{
    echo "<script>alert('修改成功！');location.href='person.php';</script>";  //跳转到person
}