<meta charset="utf-8">
<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2019/12/27
 * Time: 8:58
 */
if(!isset($_POST['submit'])) //用户直接访问本页
{
    echo "<script>alert('请从注册页面输入数据进行添加！');location.href='register.php';</script>";  //提示从添加页访问，跳转到insert
    exit;
}
$username=isset($_POST['username'])?$_POST['username']:"";  //获取username数据，没有就赋初值空串
$pass=isset($_POST['pass'])?md5($_POST['pass']):"";  //获取pass数据，没有就赋初值空串

include_once ("./conn/conn.php");   //引入数据库连接文件
$sql="insert into user(username,pass) values ('$username','$pass')";  //定义待执行的sql语句
$result=mysqli_query($link,$sql);   //3 执行sql语句
if(!$result)    //如果sql执行不成功
{
    echo "sql执行不成功，错误是：".mysqli_error($link)."你用的sql语句是".$sql;  //打印错误，打印sql语句
    exit;
}
else{
    echo "<script>alert('注册成功！');location.href='login.php';</script>";  //跳转到index
}
