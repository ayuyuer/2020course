<meta charset="utf-8">
<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2019/12/30
 * Time: 9:12
 * 提取所选的email ID，进行删除
 */
if(!isset($_GET['id'])) //用户直接访问本页
{
    echo "<script>alert('请从主页选择数据进行删除！');location.href='receive.php';</script>";  //提示从主页访问，跳转到index
    exit;
}
$id=$_GET['id'];    //获取地址栏的id参数
include_once ("./conn/conn.php");   //引入数据库连接文件
$sql="delete from email where id=$id";  //定义待执行的sql语句
$result=mysqli_query($link,$sql);   //3 执行sql语句
if(!$result)    //如果sql执行不成功
{
    echo "sql执行不成功，错误是：".mysqli_error($link)."你用的sql语句是".$sql;  //打印错误，打印sql语句
    exit;
}
else{
    echo "<script>alert('删除成功！');location.href='index.php';</script>";  //跳转到index
}
?>