<meta charset="utf-8">
<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2019/12/30
 * Time: 21:01
 * 执行添加，成功后跳转到主页
 */
session_start();
$username=$_SESSION['username'];
$id=$_GET['id'];

//获取text数据，没有就赋初值空串

$sql="update email set status=0 where id='$id'";//定义待执行的sql语句
include_once ("./conn/conn.php");   //引入数据库连接文件
//定义待执行的sql语句
$result=mysqli_query($link,$sql);   //3 执行sql语句
if(!$result)    //如果sql执行不成功
{
    echo "sql执行不成功，错误是：".mysqli_error($link)."你用的sql语句是".$sql;  //打印错误，打印sql语句
    exit;
}
else{
    echo "<script>alert('发送成功！');location.href='send.php';</script>";  //跳转到index
}
?>