
<meta charset="utf-8">
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>已发送</title><link rel="stylesheet" type="text/css" href="css/public.css"><link rel="stylesheet" type="text/css" href="css/write.css">

</head>
    <?php include_once ("underhead.php")?>
    <?php include_once ("sidebar.php")?>
    <!--content开始-->
    <div class="content">
        <?php
        /**
         * Created by PhpStorm.
         * User: Administrator
         * Date: 2019/12/30
         * Time: 上午 9:08
         * 显示数据表
         */
        include_once ("./conn/conn.php");   //引入数据库连接文件
        $id=$_GET['id'];  //获取id数据!!!!!!!!!!!!!!!!1

        include_once ("./conn/conn.php"); //引入数据库链接文件
        $sql="select * from email where id='$id'";  //定义待执行的sql语句
        $result=mysqli_query($link,$sql);//执行msql查询语句
        if(!$result)    //如果sql执行不成功
        {
            echo "sql执行不成功，错误是：".mysqli_error($link)."你用的sql语句是".$sql;  //打印错误，打印sql语句
            exit;
        }
        while( $row=mysqli_fetch_array($result))//取出结果集循环
        {

            ?>

            <table width="1000" border="1" >
                <tr>


                    <td id="re">收件人<input type="text" name="user" value="<?php echo $row['rname'];?>" style="background:none; width:940px; height:20.8px"></td>
                </tr>
                <tr>
                    <td id="title">主&nbsp;&nbsp;题 <input type="text" name="title" value="<?php echo $row['title'];?>" style="background:none;width:940px; height:20.8px;"></td>
                </tr>
                <tr>
                    <td id="nr">内&nbsp;&nbsp;&nbsp;容<input type="text" name="content" value="<?php echo $row['text'];?>" style="background:none;width:930px; height:470px;"></td>
                </tr>
            </table>
            <div class="dl">

                <a href="send.php"><input class="in1" style="text-align: center" type="submit" name="send" value="返回" ></a>

            </div>
            <?php
        }
        mysqli_free_result($result);    //6 释放结果集
        mysqli_close($link);    //7 释放连接
        ?>

    </div>
    <!--content结束-->

    <div class="clears"></div>
    <!--footer开始-->
    <div class="footer">
        <p align="center"> 2019 fish Inc. All Rights Reserved.</p>
    </div>
    <!--footer结束-->
</div>

</body>
</html>
