<meta charset="utf-8">
<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/12/27
 * Time: 上午 9:55
 */
session_start();    //开启会话管理
$_SESSION=array();  //删除所有的SESSION参数
session_destroy();  //释放会话资源
echo "<script>alert('注销成功');location.href='login.php'</script>";   //注销成功跳转到login