<meta charset="utf-8">
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>个人资料管理</title><link rel="stylesheet" type="text/css" href="css/public.css"><link rel="stylesheet" type="text/css" href="css/person.css">

    <?php include_once ("underhead.php")?>

    <?php include_once ("sidebar.php")?>
    <!--content开始-->
    <div class="content">
        <?php
        $username=$_SESSION['username'];
        include_once ("./conn/conn.php"); //引入数据库链接文件
        $sql="select * from user where username='$username'";//设置msql查询语句
        $result=mysqli_query($link,$sql);//执行msql查询语句
        $rownum=mysqli_num_rows($result);  //获取登陆匹配成功的记录条数
        //echo $sql;
        //var_dump($result);
        while($row=mysqli_fetch_array($result))     //4 循环读取结果集
        {
        ?>
        <div class="login">

            <form method="post" action="doperson.php">

                昵称<input type="text" name="name" class="user" value="<?php echo $row['name'];?>" style="color:#FFF; font-size:16px;"><br><br>

                性别<input type="text" name="gender" class="user" value="<?php echo $row['gender'];?>">
        </div>
        <div class="clears"></div>
        <div class="dl">
            <input type="hidden" name="uid" value="<?php echo $row['uid']?>">
            <input type="submit" name="submit" value="保存">
            <input type="button" onclick="window.location='index.php'"name="submit" value="取消">
        </div>
       <?php
        }
        mysqli_free_result($result);    //6 释放结果集
        mysqli_close($link);    //7 释放连接
        ?>

    </div>
    <!--content结束-->

<?php include_once ("footer.php")?>
