<meta charset="utf-8">
<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/12/26
 * Time: 19:28
 * * 执行登陆验证，成功后跳转到主页
 */
session_start();
if(!isset($_POST['submit'])) //用户直接访问本页
{
    echo "<script>alert('请从登陆页输入信息登陆！');location.href='login.php';</script>";  //提示从登陆页访问，跳转到index
    exit;
}
$username=isset($_POST['username'])?$_POST['username']:"";  //获取username数据，没有就赋初值空串
$pass=isset($_POST['pass'])?md5($_POST['pass']):"";  //获取pass数据，没有就赋初值空串
include_once ("./conn/conn.php");   //引入数据库连接文件
$sql="select * from user where username='$username' and pass='$pass'";  //定义待执行的sql语句
$result=mysqli_query($link,$sql);   //3 执行sql语句
if(!$result)    //如果sql执行不成功
{
    echo "sql执行不成功，错误是：".mysqli_error($link)."你用的sql语句是".$sql;  //打印错误，打印sql语句
    exit;
}
$rownum=mysqli_num_rows($result);  //获取登陆匹配成功的记录条数
if($rownum>=1)
{
    $_SESSION['username']=$username;


    echo "<script>alert('登陆成功！');location.href='index.php';</script>";  //跳转到index
}

else{
    echo $sql;
    echo "<script>alert('用户名或者密码不对！');location.href='login.php';</script>";  //跳转到index
}
?>
