<meta charset="utf-8">
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>登录</title>
    <link rel="stylesheet" type="text/css" href="css/public.css"><link rel="stylesheet" type="text/css" href="css/login.css">
</head>
<body>
<div>

    <!--nav开始-->
    <div class="nav">
        <div class="logo left">
            <img src="images/logo.png">
        </div>
    </div>
    <!--nav结束-->
    <div class="bg">
        <img src="images/dl-bg.png">

    </div>

    <div class="clears"></div>

    <!--content开始-->
    <div class="content">
        <!--透明图层开始-->
        <div class="back">
            <div class="login">

                <form method="post" action="dologin.php">

                    用户<input type="text" name="username" class="user" value="" style="color:#FFF; font-size:16px;"><br><br>

                    密码<input type="password" name="pass" class="user" value=""style="color:#FFF; font-size:16px;">
            </div>
            <div class="clears"></div>
            <div class="dl">
                <input type="submit" name="submit" value="登录">
                <input type="button" onclick="window.location='register.php'"name="submit" value="注册">
            </div>

        </div>
        <!--透明图层结束-->
    </div>
    <!--content结束-->
    <?php
    echo md5('1212');
    ?>

    <div class="clears"></div>
    <!--footer开始-->
    <div class="footer">
        <p align="center"> 2019 fish Inc. All Rights Reserved.</p>
    </div>
    <!--footer结束-->
</div>

</body>
</html>
