<meta charset="utf-8">
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>写信</title><link rel="stylesheet" type="text/css" href="css/public.css"><link rel="stylesheet" type="text/css" href="css/write.css">

</head>
    <?php include_once ("underhead.php")?>

    <?php include_once ("sidebar.php")?>
    <!--content开始-->

    <div class="content">
        <form method="post">
        <table width="1000" border="1" >
            <tr>


                <td id="re">收件人<input type="text" name="rname"  style="background:none; width:940px; height:20.8px"></td>
            </tr>

            <tr>
                <td id="title">主&nbsp;&nbsp;题 <input type="text" name="title" style="background:none;width:940px; height:20.8px;"></td>
            </tr>
            <tr>
                <td id="nr">内&nbsp;&nbsp;&nbsp;容<input type="text" name="text"  style="background:none;width:930px; height:470px;"></td>
            </tr>
        </table>
        <div class="dl">
            <input class="in1"style="text-align: center" type="submit" name="submit" value="发送" formaction="dowrite.php">
          <input class="in2"style="text-align: center"type="submit" name="submit" value="取消" formaction="dodraft.php">
        </div>
        </form>

    </div>
    <!--content结束-->

    <div class="clears"></div>
    <!--footer开始-->
    <div class="footer">
        <p align="center"> 2019 fish Inc. All Rights Reserved.</p>
    </div>
    <!--footer结束-->
</div>

</body>
</html>
