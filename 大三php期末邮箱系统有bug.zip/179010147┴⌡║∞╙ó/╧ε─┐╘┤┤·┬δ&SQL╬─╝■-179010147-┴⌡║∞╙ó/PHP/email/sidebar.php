<div class="sidebar">
    <ul class="topnav">
        <li><a href="write.php"><img src="images/写信.png">写信</a></li>
        <li><a href="receive.php"><img src="images/收信件.png">收件箱</a></li>
        <li><a href="send.php"><img src="images/发送.png">已发送</a></li>
        <li><a href="dustbin.php"><img src="images/删 除.png">已删除</a></li>
        <li><a href="draft.php"><img src="images/草稿箱(1).png">草稿箱</a></li>
        <li><a href="person.php"><img src="images/个人资料 (1).png">个人资料管理</a></li>
    </ul>
</div>


<div class="clears"></div>