<meta charset="utf-8">
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>注册</title><link rel="stylesheet" type="text/css" href="css/public.css"><link rel="stylesheet" type="text/css" href="css/register.css">
</head>

<body>
<div>

    <!--nav开始-->
    <div class="nav">
        <div class="logo left">
            <img src="images/logo.png">
        </div>
    </div>
    <!--nav结束-->
    <div class="bg">
        <img src="images/zc-bg.png">

    </div>

    <div class="clears"></div>

    <!--content开始-->
    <div class="content">
        <!--透明图层开始-->
        <div class="back">
            <div class="login">

                <form method="post" action="doregister.php">

                    用户<input type="text" name="username" class="user" value="" style="color:#FFF; font-size:16px;"><br><br>

                    密码<input type="text" name="pass" class="user" value="" style="color:#FFF; font-size:16px;"><br><br>
                    <div class="check">
                        <input type="checkbox"><p>已同意用户协议</p>
                    </div>
            </div>

            <div class="clears"></div>
            <div class="dl">
                <input type="submit" name="submit" value="确认">
                <input type="button" onclick="window.location='login.php'"name="submit" value="取消">
            </div>


        </div>
        <!--透明图层结束-->
    </div>
    <!--content结束-->

    <div class="clears"></div>
    <!--footer开始-->
    <div class="footer">
        <p align="center"> 2019 fish Inc. All Rights Reserved.</p>
    </div>
    <!--footer结束-->
</div>

</body>
</html>
