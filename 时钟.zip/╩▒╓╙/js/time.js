let btn = document.getElementById("btn");
let text = document.getElementById("text");
let time = 5;
let timeGo = function () {
    time--;
    text.innerHTML = time;

    //判断计时器
    if(time<=0)
    {
        btn.disabled = false;//可点击
        clearInterval(myset);//去掉计时器
    }
    console.info("time");
};
//添加点击事件
btn.addEventListener("click",function () {
    console.info("yes");
});
let myset = setInterval( timeGo ,1000 );//计时器