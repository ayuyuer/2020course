
let year = document.getElementById("year");
let month= document.getElementById("month");
let day = document.getElementById("day");
let week = document.getElementById("week");
let h1 = document.querySelector("#h1");
let h2 = document.querySelector("#h2");
let f1 = document.querySelector("#f1");
let f2= document.querySelector("#f2");
let m1 = document.querySelector("#m1");
let m2 = document.querySelector("#m2");

let myDate = new Date();//获取系统当前时间


const xqsz = ["日","一","二","三","四","五","六"];//周数组
year.innerHTML = myDate.getFullYear(); //得到年份
month.innerHTML = myDate.getMonth()+1;//得到月份
day.innerHTML = myDate.getDate();//得到日期
week.innerHTML = xqsz[myDate.getDay()];//放入数组，得到周转换

let pics=[
    "images/0.png",
    "images/1.png",
    "images/2.png",
    "images/3.png",
    "images/4.png",
    "images/5.png",
    "images/6.png",
    "images/7.png",
    "images/8.png",
    "images/9.png"
];

let timeGo = function(){
    let mydate = new Date();//获取系统当前时间
    let  miao = mydate.getSeconds();
     let mG = miao%10;//个位数上0-9
    let mS = Math.floor(miao/10);//十位数上0-9
    m2.src =pics[mG];
    m1.src =pics[mS];

    let  fen = mydate.getMinutes();
    let fG = fen%10;//个位数上0-9
    let fS = Math.floor(fen/10);//十位数上0-9
    f2.src =pics[fG];
    f1.src =pics[fS];
    let  hour = mydate.getHours();
    let sG = hour%10;//个位数上0-9
    let sS = Math.floor(hour/10);//十位数上0-9
    h2.src =pics[sG];
    h1.src =pics[sS];

};

let mySet = setInterval(timeGo,500);

