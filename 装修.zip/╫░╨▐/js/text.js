{
    let picUl = document.getElementById("picUl");
    let ctrls = document.querySelector("#ctrls");
    let dots = ctrls.children;
    let pre = document.getElementById("pre");
    let next = document.getElementById("next");
    let nav = document.getElementById("nav");
    let li = nav.children;

    let slideShow = document.getElementById("slideShow");
    let sp = slideShow.children;
    let jdSelect = document.getElementById("jdSelect");
    let jdshow = jdSelect.children;


    //banner切换
    let imgs = [{
        img: "images/banner2.png"
    }, {
        img: "images/banner1.png"
    }, {
        img: "images/banner3.png"
    }];

    //默认图
    let index = 0;
    //
    let showPic = function (index) {
        picUl.style.background = `url("${ imgs[index].img }") top center no-repeat`;
        console.info(imgs[index].img);
        dots[index].classList.add("on");//添加on
        removeSiblingsClass(dots[index], "on");//去掉on
    };


    //找兄弟节点
    let findSiblings = function (tag) {
        let child = tag.parentNode.children;
        let siblings = [];
        for (let i = 0; i <= child.length - 1; i++) {
            if (child[i] === tag) {
                continue;
            }
            siblings.push(child[i]);
        }
        return siblings;
    };

    // 去掉兄弟节点的类
    let removeSiblingsClass = function (tag, cName) {
        let xd = findSiblings(tag);
        for (let i = 0; i <= xd.length - 1; i++) {
            xd[i].classList.remove(cName);
        }
    };

    //默认显示索引为1的图片：第一张
    showPic(index + 1);

    prev.addEventListener("click", function (event) {
        index--;
        if (index <= -1) {
            index = imgs.length - 1;
        }

        showPic(index);

    });
    next.addEventListener("click", function (event) {
        index++;
        if (index > imgs.length - 1) {
            index = 0;
        }

        showPic(index);

    });
    for (let i = 0; i <= dots.length - 1; i++) {
        dots[i].addEventListener("mouseenter", function () {
            index = i;
            showPic(index);
        });
    }
//轮播
    function lunbo(event) {

        index++;
        if (index > imgs.length - 1) {
            index = 0;
        }
        showPic(index);

        for (let j = 0; j <= dots.length - 1; j++) {
            dots.className = "";
        }
        dots[index].className = "on";
    }
    setInterval("lunbo()",2000);
    //二级菜单

    for (let i = 0; i <= li.length - 1; i++) {
        li[i].addEventListener("mouseenter", function (event) {
            let nowLi = event.currentTarget;
            let ul = nowLi.children[1];
            if (!ul) {    // 判断标签是否存在，不存在
                return false;  // 终止函数运行
            }
            // 显示标签, 增加类 on
            ul.classList.add("on");
        });

        li[i].addEventListener("mouseleave", function (event) {
            let nowLi = event.currentTarget;
            let ul = nowLi.children[1];
            if (!ul) {        // 判断标签是否存在，不存在
                return false;  // 终止函数运行
            }
            // 隐藏，去掉类 on
            ul.classList.remove("on");
        });
    }

    //经典案例选项卡
    for(let i = 0; i<sp.length;i++){
        sp[i].index = i;
        sp[i].onmouseenter = function () {
            for(let m = 0; m<jdshow.length;m++){
                sp[m].className = "";
                jdshow[m].style.display ="none";
            }
            this.className = "show";
            jdshow[this.index].style.display = "block";
        }
    }


// $(".navLi").mouseenter(function () {
//
// })


}